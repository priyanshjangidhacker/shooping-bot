const form = document.getElementById("chatForm");
const input = document.getElementById("userInput");
const messages = document.getElementById("messages");

form.addEventListener("submit", function (event) {
  event.preventDefault();

  const text = input.value.trim();
  if (!text) return;

  addMessage(text, "user");
  input.value = "";

  setTimeout(() => {
    const reply = getBotReply(text);
    addMessage(reply, "bot");
  }, 500);
});

function addMessage(text, type) {
  const message = document.createElement("div");
  message.className = `${type} message`;
  message.textContent = text;
  messages.appendChild(message);
  messages.scrollTop = messages.scrollHeight;
}

function getBotReply(text) {
  const query = text.toLowerCase();

  if (query.includes("headphone") || query.includes("earphone")) {
    return "I found Wireless Headphones for ₹1,999. 🎧";
  }

  if (query.includes("watch")) {
    return "Our Smart Watch is available for ₹2,499. ⌚";
  }

  if (query.includes("laptop")) {
    return "Our featured laptop is ₹54,999. 💻";
  }

  if (query.includes("price") || query.includes("cost")) {
    return "Tell me the product name and I'll show you the available price.";
  }

  return "I can help you find headphones, smart watches, laptops, and more. Try asking for one!";
}
