# Shopping Bot

A simple responsive shopping assistant website built with HTML, CSS and JavaScript.

## Run locally

Open `index.html` in a web browser.

## GitHub Pages

Upload all files to the root of your GitHub repository, including `index.html`, `style.css`, and `script.js`.

Then enable:

Settings → Pages → Deploy from a branch → `main` → `/ (root)`.
